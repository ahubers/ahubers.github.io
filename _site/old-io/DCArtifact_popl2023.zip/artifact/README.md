# A Type-Based Approach to Divide-And-Conquer Recursion in Coq

Artifact submitted for evaluation. This README is headered and organized according
to the POPL'23 recommendations found
[here](https://popl23.sigplan.org/track/POPL-2023-artifact-evaluation#Author-Recommendations), and is available
in both [Markdown](./README.md) and [PDF](./README.pdf) format.


# Download, installation, and sanity-testing

This artifact may be fully built and installed either **manually** or via
**Docker**.


### Which installation should I use?
Docker installation is faster & easier -- however, we are not entirely sure how
a docker installation will integrate with your favorite IDE. Installation via
Docker will build the artifact in entirety and allow you to interact with it via
shell. You may need to perform a manual installation if you want to interact
with proofs incrementally, i.e., with a goal buffer and all of your favorite
tools.

In short, **we offer Docker installation to guarantee the successful delivery of
our artifact**, but you may find you want to perform a manual installation in
order to interface with the artifact more completely.

## Docker Installation

First, install [Docker
Desktop](https://www.docker.com/products/docker-desktop/).  Then,
run (in this directory):

```sh
docker build -t dc-image .
docker run -dt --name dc-container -v $(pwd):/home/coq/dc/ dc-image
```

The first command builds a docker image with precisely the desired Coq version
and dependencies installed. The second command boots up that image as a
container with a **shared drive** between this directory and `/home/coq/dc`
within the container.

We can now build the development in the docker container via:

```sh
docker exec -it dc-container sh make-all
```

This will build all of the coq files & documentation. Documentation is placed in
`./html`.


### Docker Help & FAQ

Once the container is built and running, you can shell into it via

```sh
docker exec -ti dc-container sh
```

If commands such as `coqtop` do not work, you may need to export all `opam`
environment variables to the shell session via

```sh
eval $(opam env)
```

once inside the container. Instructions for artifact evaluation in this file
will be given under the presumption that you have an active shell session in
this docker container (or, locally, if you have chosen manual installation).

If you ever need to wipe the whole thing and start over, run
```sh
 docker container stop dc-container; 
 docker container rm dc-container; 
 docker volume rm dc;
```

## Manual Installation

Manual installation instruction can be found [here](./manual-install.md).

# List of Claims

We claim the following list of contributions in **Section (1), Recursion In Coq**.

## Claim (1)
> Formulation of an interface for divide-and-conquer recursion in Coq (Section
> 4). The formulation is generic for any signature functor, and so applies once
> and for all to a large, standardly used family of datatypes, including natural
> numbers, lists, binary and other forms of trees, and many other common
> examples. It does not make use of dependent types, and users of the interface
> do not prove statements showing that the arguments decrease. Instead, the
> typing of CC is used to enforce termination.

## Claim (2)

> Realistic examples in Coq coded against this interface (Section 5), including
> quicksort, mergesort, run-length encoding, and a function wordsBy, which
> breaks a list into its maximal sublists whose elements do not satisfy a
> predicate p. Another example is Harper’s regular expression matcher, which has
> been posed as a challenge problem for termination.

## Claim (3)
> Derivation within Coq of an implementation of the interface (Section 6).

## Claim (4)
> Formulation and implementation of a dependently typed version of the
> interface, yielding a divide-and-conquer induction principle (Section
> 7). Proofs using this principle are demonstrated for the above examples,
> including that the sorting algorithms indeed sort.

### Regarding performance claims

Note that the list of contributions (in the paper) also asserts:

> A further contribution is a detailed consideration of well-founded recursion
> in Coq (Section 3), as implemented by the commands Function, Program, and
> Equations. We point out several issues, to motivate the alternative approach
> we propose.

We have chosen to omit this as a claimed (and therefore verified) contribution
for the following reasons

- **The claim bolsters the contribution's _motivation_, not the contribution
  itself.** We offer this detailed consideration of well-founded recursion to
  motivate the use of our development. We do not believe it to be a contribution
  of our central work, which we define in claims 1-4.
- **Our performance claims are subject to change in the future as per our
  conditional acceptance**. Reviewers have requested changes to the performance
  claims (and code) included in our paper. So any work on behalf of the
  evaluator to verify these claims may end up being discarded.

# Evaluation Instructions

## Evaluating Claim (1)

We have the following subclaims:

### Claim 1.1

> The formulation is generic for any signature functor ...

You can verify in [Dc.v](./Dc/Dc.v) that our generic development is
parameterized by any functor `F`. See the following code excerpt (and confirm it leads `Dc.v`):

```coq
Section Dc.
  Variable F : Set -> Set.
  Context {FunF : Functor F}.
```

### Claim 1.2
> ... and so applies once and for all to a large, standardly used family of
> datatypes, including natural numbers, lists, binary and other forms of trees,
> and many other common examples.

You can verify in the following files that our formulation can be used to derive
the following standardly used datatypes:

- Lists are derived in [List.v](./List/List.v).
- Nats are derived in [Nat.v](Nat/Nat.v).
- Additionally, Trees & Lists are generated automatically using IDT and MetaCoq
  (see \S6.4 of paper) in [Example.v](FunctorGenerators/Example.v).
  
  
### Claim 1.3

> It does not make use of dependent types, and users of the interface
> do not prove statements showing that the arguments decrease.

This is sort of a broad claim. Firstly: our generic development is in
[Dc.v](./Dc/Dc.v), which you can verify does not use dependent types.

The larger argument we are making is that we may write functions, e.g.
`mergesort`, without any dependent proof obligations of argument decrease. For
examlpe, contrast the proof obligations in defining `mergesortHWf` in
[MergesortWf.v](./Mergesort/MergesortWf.v):

```coq
  Function mergeSortHWf
    (a : A) (l:list A) {measure length l} : list A :=
    match l with
    | nil => [a]
    | (x :: xs) => let ret := split xs in
               merge (mergeSortHWf a (fst ret)) (mergeSortHWf x (snd ret))
    end.
  intros; destruct (splitSmaller xs); simpl; apply Nat.lt_succ_r; assumption.
  intros; destruct (splitSmaller xs); simpl; apply Nat.lt_succ_r; assumption.
  Qed. 
```	

with the definition in [Mergesort.v](./Mergesort/Mergesort.v):

```coq
  Definition mergeSortH (xs : List A) (x : A) :=
    fold (ListF A) (Const  (A -> list A)) (FunConst (A -> list A)) (MergeSortAlg) xs x.
```

### Claim 1.4

> Instead, the typing of CC is used to enforce termination.

This follows simply from examples like `mergesort` type checking in Coq.

## Evaluating Claim (2)

We have the following subclaims:

### Claim 2.1 

> Realistic examples in Coq coded against this interface (Section 5), including
> quicksort ...

Quicksort is defined in [Quicksort.v](Quicksort/Quicksort.v). Sample executions
are placed in [RunMe.v](Quicksort/RunMe.v), which you can execute and print to
file `Quicksort/RunMe.out` via:

```sh
coqc -impredicative-set -R ./ DivConq Quicksort/RunMe.v > Quicksort/RunMe.out
```

### Claim 2.2 

> ... mergesort ..

Mergesort is defined in [Mergesort.v](Mergesort/Mergesort.v). Sample executions
are placed in [RunMe.v](Mergesort/RunMe.v), which you can execute and print to
file `Mergesort/RunMe.out` via:

```sh
coqc -impredicative-set -R ./ DivConq Mergesort/RunMe.v > Mergesort/RunMe.out
```

### Claim 2.3
> ... run-length encoding ...

Run-length encoding and decoding are defined in [Rle.v](Rle/Rle.v) and
[Rld.v](Rle/Rld.v), respectively (run-length _decoding_ is _not_ defined using
our interface). Sample executions are placed in [RunMe.v](Rle/RunMe.v),
which you can execute and print to file `Rle/RunMe.out` via:

```sh
coqc -impredicative-set -R ./ DivConq Rle/RunMe.v > Rle/RunMe.out
```

### Claim 2.4
> ... and a function wordsBy, which breaks a list into its maximal sublists whose
> elements do not satisfy a predicate p. ...

`WordsBy` is defined in [WordsBy.v](Wordsby/WordsBy.v). A sample execution is
placed in [RunMe.v](Wordsby/RunMe.v), which you can execute and print to file
`Wordsby/RunMe.out` via:

```sh
coqc -impredicative-set -R ./ DivConq Wordsby/RunMe.v > Wordsby/RunMe.out
```

### Claim 2.5
> Another example is Harper’s regular
> expression matcher, which has been posed as a challenge problem for
> termination.

Harper's regular expression matcher is defined in
[Matcher.v](./Harpers/Matcher.v). A sample execution is placed in
[RunMe.v](Harpers/RunMe.v), which you can execute and print to file
`Harpers/RunMe.out` via:

```sh
coqc -impredicative-set -R ./ DivConq Harpers/RunMe.v > Harpers/RunMe.out
```


## Evaluating Claim (3)

We claim solely in **Claim (3)**, a

> Derivation within Coq of an implementation of the interface (Section 6).

In \S6.1, we derive retractive-positive recursive types. These are found in
[Mu.v](./Dc/Mu.v). In \S6.2, we derive the `Dc` type. This is found in
[Dc.v](./Dc/Dc.v).

The reviewer can verify a parity between the paper and the development, and that
the development compiles by running

```
./make-all
```
## Evaluating Claim (4)

We have the following subclaims:

### Claim 4.1 
> Formulation and implementation of a dependently typed version of the
> interface, yielding a divide-and-conquer induction principle (Section 7).

The dependently typed interface is discussed in \S7 and defined in
[Mui.v](./Dc/Mui.v) and [Dci.v](./Dc/Dci.v). We will show in the next subclaim
that this interface leads to valid reasoning principles over our data types.


### Claim 4.2 

> Proofs using this principle are demonstrated for the above examples, including
> that the sorting algorithms indeed sort.

Below we give the location of each proof of correctness. The
reviewer can verify each proof by inspecting the proof's type signature and
confirming the proof's file compiles.

- In \S7.1, we claim to have proven the theorem `RldRle`. The theorem states
  that run-length decoding is inverse to run-length encoding, and is found in
  [Rle/Rle.v](./Rle/Rle.v) at line 46.
- In \S7.2, we claim to have proven that `mergesort` does indeed
sort. Mergesort's correctness is proven by the theorem `mergeSortSorts` in
[MergesortProofs.v](./Mergesort/MergesortProofs.v) at line 174. In particular, we
prove that `(mergesort l)` is strongly sorted for any list `l`.
- In \S7.2, we claim to first need to prove the correctness of `partition`
  before proving the correctness of `quicksort`. 
  - The key partition lemma is proven by `partitionLem` in
    [PartitionSimpleProofs.v](./Quicksort/PartitionSimpleProofs.v) at line 68.
  - Quicksort's correctness is proven by the theorem `Qsorted` in
    [QuicksortProofs.v](./Quicksort/QuicksortProofs.v) at line `118`. We assert
    that `(quicksort l)` is strongly sorted for any suitable list `l`.

# Additional Artifact Description

## Documentation
Included in [./html/](./html/) is html documentation generated by
[coqdoc](https://coq.inria.fr/refman/using/tools/coqdoc.html). You can view a
table of contents by opening [./html/toc.html](./html/toc.html) in the browser
of your choice.

Documentation can be regenerated by running `make html`.

## Code Snippets & Figures Index

Below we have indexed most code found in the paper by (sub)section and location
in this codebase.

## \S3

| Section | Figure | Location | Description |
| :-: |    :-:   | :--: |   :---: |
| \S3.1 | Figure 1 | [WordsBy.hs](./Wordsby/WordsBy.hs) | The `WordsBy` function in Haskell. |
| \S3.2 | Figure 2 | [WordsByWf.v](./Wordsby/WordsByWf.v) | Using `Program` to generate a well-founded version of `wordsBy`.|
| \S3.2 | Figure 3 | [WordsByEq.v](./Wordsby/WordsByEq.v) | Using `Equations` to generate a well-founded version of `wordsBy`.|
| \S3.6 |  | [SmallerList.v](./List/SmallerListWf.v) | A custom ordering introduced directly on the `list` data type. |


## \S4


| Section | Figure | Location | Description |
| :-: |    :-:   | :--: |   :---: |
| \S4.1 |  | [List.v](./List/List.v) | The `List` data type as a signature functor & definition of `lengthAlg`. |
| \S4.2 |  | [Kinds.v](./Dc/Kinds.v) | The `KAlg` kind. |
| \S4.2 |  | [Dc.v](./Dc/Dc.v) | Definition of our divide and conquer interface: the types `SAlg`, `FoldT`, `Alg`, and `Dc`, and functions `inDc`, `fold`, `sfold`, and `out`. |


## \S5

| Section | Figure | Location | Description |
| :-: |    :-:   | :--: |   :---: |
| \S5.1.1 | Figure 7 | [Span.v](./Span/Span.v) | The `Span` (and helper `spanr`) function. |
| \S5.1.2 | Figure 8 | [WordsBy.v](./Wordsby/WordsBy.v) | The `WordsBy` function. |
| \S5.1.2 | Figure 9 | [mapThrough.hs](./Wordsby/WordsBy.v) | The `WordsBy` function. |
| \S5.2.1 | Figure 10 | [MapThrough.v](./Rle/MapThrough.v) | The `mapThrough` combinator. |
| \S5.2.2 | Figure 11 | [Rle.hs](./Rle/Rle.hs) | `mapThrough` and run-length encoding in Haskell.  |
| \S5.2.2 | Figure 12 | [Rle.v](./Rle/Rle.v) | Run-length encoding.   |
| \S5.2.2 | Figure 13 | [MapThroughWf.v](./Rle/MapThroughWf.v) | Using `Program` to generate a well-founded version of `mapThrough`.  |
| \S5.3 | Figures 14 & 15 | [Matcher.v](./Harpers/Matcher.v) | Harper's matcher.  |
| \S5.4 | Figures 16 & 17 | [Mergesort.v](./Mergesort/Mergesort.v) | `mergesort` implemented using `split`.  |
| \S5.5 | Figures 18 & 19 | [Quicksort.v](./Quicksort/Quicksort.v) | `quicksort` implemented using `partition`.  |

## \S6
| Section | Figure | Location | Description |
| :-: |    :-:   | :--: |   :---: |
| \S6.1 | Figure 20 | [Mu.v](./Dc/Mu.v) | Derivation of retractive-positive recursive types.  |
| \S6.2 | Figure 21 | [Dc.v](./Dc/Dc.v) | Definition of `promote`.  |

## \S7

| Section | Figure | Location | Description |
| :-: |    :-:   | :--: |   :---: |
| \S7   |   | [Dci.v](./Dc/Dci.v) | Derivation of Divide & Conquer induction.  |
| \S7   |   | [Rle.v](./Rle/Rle.v) | The decoding property for `rle`.  |
| \S7.1 | Figure 22  | [SpanPfs/](./Span/SpanPfs/) | Formulations of three lemmas about span. |
| \S7.2 | Figure 23  | [MotivePres.v](./Span/SpanPfs/MotivePres.v) | Carrier for proving that `Split` preserves motives. |
| \S7.3 | Figure 24  | [Forall.v](./Span/SpanPfs/Forall.v) | Motive used to avoid noncanoicity problems. |
